package tests

import org.scalatest._

class TestBatteries extends FunSuite{

  test("Check method decreases battery's charge"){

  }

  test("Check method replaces battery"){
    
  }

}
