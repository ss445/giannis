//package tests

import org.scalatest._
import physics.PhysicsVector

//class TestVector extends FunSuite {

 // test("Check method multiplies by a constant"){

   // val origin: PhysicsVector = new PhysicsVector(0, 0, 0)
    //val jayZ: PhysicsVector = new PhysicsVector(4,4,4)
    //val illmatic: PhysicsVector = new PhysicsVector(6, 6, 6)
    //assert(origin.multiplyByConstant(2)== (0,0,0))
    //assert(jayZ.multiplyByConstant(3)== (12,12,12))
    //assert(illmatic.multiplyByConstant(3)== (18,18,18))
  //}
  //test("Check method adds vector values"){

    //val yaya: PhysicsVector = new PhysicsVector(3,3,3)
    //val tommy: PhysicsVector = new PhysicsVector(2,2,2)
   // val cLeeRay: PhysicsVector = new PhysicsVector(8,8,8)
    //assert(yaya.addVector(tommy)== (5,5,5))

  //}

//}
