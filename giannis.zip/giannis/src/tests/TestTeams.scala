package tests

import org.scalatest._

class TestTeams extends FunSuite {

  test("Check referee object keeps correct score"){

  }
}
