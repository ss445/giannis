package execution

class Battery(charge: Int) {

}
