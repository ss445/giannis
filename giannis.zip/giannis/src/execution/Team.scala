package execution

class Team(val Offense: Int, val Defense: Int) {

  var score: Int = 0


}
