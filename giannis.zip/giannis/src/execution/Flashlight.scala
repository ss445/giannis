package execution

//class Flashlight() {

  //var battery: Battery = new Battery(5)

  //def use(): Unit = {

  //}

  //def replaceBattery(replaceIt: Battery): Battery = {
    //replaceIt = battery
 // }

//}
