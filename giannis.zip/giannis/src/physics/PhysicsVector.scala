package physics

class PhysicsVector(var x: Double, var y: Double, var z: Double) {

      def multiplyByConstant(ring: Double): Unit = {
        this.x *= ring
        this.y *= ring
        this.z *= ring
      }
      def addVector(now: PhysicsVector): Unit = {
        this.x += now.x
        this.y += now.y
        this.z += now.z
      }

}
